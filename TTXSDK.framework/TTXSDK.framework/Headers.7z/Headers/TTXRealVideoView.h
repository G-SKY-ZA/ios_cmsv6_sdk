//
//  TTXRealVideoView.h
//  TTXSDK
//
//  Created by tongtianxing on 2019/6/27.
//  Copyright © 2019 tongtianxing. All rights reserved.
//



#define PTZ_MOVE_LEFT           0
#define PTZ_MOVE_RIGHT          1
#define PTZ_MOVE_TOP            2
#define PTZ_MOVE_BOTTOM         3
#define PTZ_MOVE_LEFT_TOP       4
#define PTZ_MOVE_RIGHT_TOP      5
#define PTZ_MOVE_LEFT_BOTTOM    6
#define PTZ_MOVE_RIGHT_BOTTOM   7
#define PTZ_FOCUS_DEL           8
#define PTZ_FOCUS_ADD           9
#define PTZ_LIGHT_DEL           10
#define PTZ_LIGHT_ADD           11
#define PTZ_ZOOM_DEL            12
#define PTZ_ZOOM_ADD            13
#define PTZ_LIGHT_OPEN          14
#define PTZ_LIGHT_CLOSE         15
#define PTZ_WIPER_OPEN          16
#define PTZ_WIPER_CLOSE         17
#define PTZ_CRUISE              18
#define PTZ_MOVE_STOP           19
#define PTZ_PRESET_MOVE         21
#define PTZ_PRESET_SET          22
#define PTZ_PRESET_DEL          23

#define PTZ_SPEED_MIN           0
#define PTZ_SPEED_MAX           255
#define PTZ_SPEED_DEFAULT       128

#define TTXPLAY_STREAM_MODE_FILE        1
#define TTXPLAY_STREAM_MODE_REAL        2
#define TTXPLAY_STREAM_MODE_STREAM      3

#import <UIKit/UIKit.h>
/**
 * 实时视频播放类 Real-time video play
 * 查看服务器下设备视频需要配置TTXSDKPrepare的服务器ip和端口,通过实例TTXRealVideoView,
 * 配置"setViewInfo",调用"StartAV"即可预览实时视频.
 * 查看直连设备视频只需要配置"setViewInfo"和"setLanInfo"即可预览实时视频
 * 有关更多用法，请参阅cmsv6demo。
 * To view the device video under the server, you need to configure the server ip and port of TTXSDKPrepare.
 * Configure the "setViewInfo" through the instance TTXRealVideoView and call "StartAV" to preview the live video.
 * View direct device video only need to configure "setViewInfo" and "setLanInfo" to preview live video
 * For more usage, please refer to cmsv6demo.
 */
@interface TTXRealVideoView : UIView
/**
 *  配置需要预览视频的参数 Configure parameters that need to preview the video
 *  @param _devIdno 设备ID  Device ID
 *  @param _channel 通道    Channel
 *  @param _mode    码流    Code stream    (0 Main stream 1 Substream)
 */
-(void)setViewInfo:(NSString *)_devIdno chn:(int)_channel mode:(int)_mode;
/**
 *  配置预览视频标题
 *  @param _devName 设备名字 Device Name
 *  @param _chnName 通道名字 Channel Name
 */
-(void)setTitleInfo:(NSString *)_devName chName:(NSString*)_chnName;

/**
 * 直连设备预览视频需要配置的服务器ip和端口
 * Directly connected device preview video requires configuration of server ip and port
 * @param _lanIp   服务器IP Server IP
 * @param _lanPort 端口     Port
 */
- (void)setLanInfo:(NSString*)_lanIp port:(int)_lanPort;
/**
 * 开始视频预览 Start the video preview
 */

- (BOOL)StartAV;
/**
 * 停止视频预览 Stop the video preview
 */

- (BOOL)StopAV;

/**
 * 判断是否正在预览 Determine if video is previewing
 */
- (BOOL)isViewing;

/**
 * 截图到相册  Screenshot to album
 */
- (BOOL)savePngFile;

/**
 * 云台控制 PTZ control
 * @param command  命令 (PTZ_MOVE_LEFT~PTZ_PRESET_DEL)
 * @param nSpeed   速度    (PTZ_SPEED_MIN~PTZ_SPEED_MAX)
 * @param nParam   预制位
 */
- (void)ptzControl:(int)command speed:(int )nSpeed param:(int)nParam;

/**
 * 判断是否正在录像 Determine if the video is being recorded
 */
- (BOOL)isRecording;

/**
 * 启动或停止录像 Start or stop recording
 */
- (void)record;

/**
 * 启动录像 start Record
 */
- (BOOL)startRecord;

/**
 * 停止录像 stop Record
 */
- (BOOL)stopRecord;

/**
 * 开始声音播放 play Sound
 */
- (void)playSound;

/**
 * 停止声音播放 stop Sound
 */
- (void)stopSound;

/**
 * 是否正在声音播放 stop Sound
 */
- (BOOL)isSounding;

/**
* 选择流模式 Select a stream mode
* 默认TTXPLAY_STREAM_MODE_STREAM模式   defalut   TTXPLAY_STREAM_MODE_STREAM
* 实时请用TTXPLAY_STREAM_MODE_REAL模式  realMode  TTXPLAY_STREAM_MODE_REAL
* 该接口需要在调用StartAV前调用         This interface needs to be called before calling StartAV
*/
- (void)setStreamMode:(int)sMode;

/**
* 设置最大和最小延时时间    ms
* Set maximum and minimum delay times
* 该接口需要在调用StartAV前调用         This interface needs to be called before calling StartAV
*/
- (void)setMinMinsecond:(unsigned long)mms maxMinSecond:(unsigned long)mms2;



@end
