//
//  TTXDeviceSearchModel.h
//  TTXSDK
//
//  Created by tongtianxing on 2019/6/27.
//  Copyright © 2019 tongtianxing. All rights reserved.
//

#import <Foundation/Foundation.h>
@interface TTXDeviceSearchModel : NSObject
@property (nonatomic, copy) NSString* devIdno;      //设备Id          device ID
@property (nonatomic, assign) NSInteger netType;    //网络连接方式 net type (0 - 3G , 1 - Wifi , 2 - Net)
@property (nonatomic, copy) NSString* netName;		//(wifi)名字      (wifi)name
@property (nonatomic, copy) NSString* ipAddr;       //ip              ip
@property (nonatomic, assign) NSInteger devType;    //MDVR
@property (nonatomic, assign) NSInteger channel;    //通道            channel
@property (nonatomic, assign) NSInteger webPort;    //端口             port
@property (nonatomic, copy) NSString* webUrl;       //http://"ipAddr":"webPort"/"webUrl"
@end
