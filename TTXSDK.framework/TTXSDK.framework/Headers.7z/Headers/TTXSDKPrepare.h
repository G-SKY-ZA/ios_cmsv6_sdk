//
//  TTXSDKPrepare.h
//  TTXSDK
//
//  Created by tongtianxing on 2019/6/27.
//  Copyright © 2019 tongtianxing. All rights reserved.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN
/**
 *初始化SDK配置 Initialize the SDK configuration
 */
@interface TTXSDKPrepare : NSObject

+(TTXSDKPrepare *)prepare;
/**
 * 初始化SDK              Initialize the SDK
 */
-(void)initializationSDK;
/**
 * 设置服务器会话号         Set the server session number
 * @param jsession     配置从web接口获取
 */
-(void)setJsession:(NSString *)jsession;
/**
 * 设置服务器ip和登陆端口 (服务器ip通常填一样)
 * Set server ip and port (Server IP and server LAN IP are usually the same)
 * @param server   服务器ip       Server IP
 * @param server2  服务器局域网ip  Server LAN IP
 * @param port     端口           port     (port为0时默认6605 The default is 6605 when port is 0)
 */
-(void)setServer:(NSString *)server lanIP:(NSString *)server2 port:(int)port;

@end

NS_ASSUME_NONNULL_END
