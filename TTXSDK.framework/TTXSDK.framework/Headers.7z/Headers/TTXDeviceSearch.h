//
//  TTXDeviceSearch.h
//  TTXSDK
//
//  Created by tongtianxing on 2019/6/27.
//  Copyright © 2019 tongtianxing. All rights reserved.
//


#import <Foundation/Foundation.h>
NS_ASSUME_NONNULL_BEGIN
/**
 *搜索结果回调 Search result callback
 */
@protocol TTXDeviceSearchDelegate <NSObject>
-(void)searchFinishHaveDevice:(NSArray *)searchList;
@end

/**
 *设备搜索类 Device search class
 *初始化配置代理后直接调用startSearchDevice,结束后通过代理返回结果.
 *Call "startSearchDevice" directly after initializing the configuration proxy, and return the result
 *through the proxy after the end.
 */
@interface TTXDeviceSearch : NSObject

@property (nonatomic , assign)id delegate;
/**
 *开启设备搜索  start device search
 */
- (void)startSearchDevice;
/**
 *停止设备搜索 stop device search
 */
- (void)stopSearchDevice;
@end

NS_ASSUME_NONNULL_END
