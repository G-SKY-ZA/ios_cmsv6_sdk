//
//  TTXPlaybackSearch.h
//  TTXSDK
//
//  Created by tongtianxing on 2019/6/27.
//  Copyright © 2019 tongtianxing. All rights reserved.
//



#import <Foundation/Foundation.h>

@protocol TTXPlaybackSearchDelegate<NSObject>
/**
 * 搜索结果回调 Search result callback
 */
-(void)searchFinishHavePlayback:(NSArray *)searchList;
/**
 * 搜索错误 Search error
 */
-(void)searchError:(NSString*)error;
@end

/**
 *回放搜索类    Playback search class
 *初始化配置代理后直接调用"onsearch",通过代理返回包含"TTXPlaybackSearchModel"实例的数组
 *Call "onsearch" directly after initializing the configuration proxy, returning an array
 *containing the "TTXPlaybackSearchModel" instance via the proxy
 */
@interface TTXPlaybackSearch : NSObject
@property (nonatomic , assign)id<TTXPlaybackSearchDelegate> delegate;
/**
 * 搜索回放
 * @param devIdno 设备ID
 * @param devChnCout 设备视频通道数目
 * @param vehiId  车辆ID(20200103 新增,车牌号过长时使用,可不传)
 * @param location 文件位置 0终端磁盘 1下载服务器 2存储服务器
 * @param channel 通道-1为全部
 * @param fileType 录像类型 -1为全部
 * @param queryDate 日期 例:2019-06-26
 * @param beginSecond 开始时间 s 0~86400
 * @param endSecond  结束时间  s 0~86400
 */
-(void)onsearch:(NSString *)devIdno vehiIdno:(NSString *)vehiIdno vehiId:(int)vehiId devChnCout:(int)devChnCout location:(int)location channel:(int)channel type:(int)fileType date:(NSString *)queryDate beginTime:(int)beginSecond endTime:(NSInteger)endSecond;
/**
 * 搜索强制结束
 */
-(void)cancelSearch;


@end
